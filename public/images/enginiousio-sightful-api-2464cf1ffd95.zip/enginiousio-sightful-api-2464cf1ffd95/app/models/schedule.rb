class Schedule < ActiveRecord::Base
    belongs_to :invitee , foreign_key: :invitee , class_name: 'User'
    belongs_to :host , foreign_key: 'host_id' , class_name: 'User'
    has_many :user_schedules
    has_many :users , through: :user_schedules
end