class Work < ActiveRecord::Base
  belongs_to :user
end
