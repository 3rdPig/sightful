class Education < ActiveRecord::Base
  belongs_to :user
end
