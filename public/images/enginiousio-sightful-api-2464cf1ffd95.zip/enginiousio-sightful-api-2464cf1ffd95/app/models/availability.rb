class Availability < ActiveRecord::Base
  belongs_to :user
end