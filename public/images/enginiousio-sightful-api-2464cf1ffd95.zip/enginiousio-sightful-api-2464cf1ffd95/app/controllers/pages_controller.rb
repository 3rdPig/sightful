class PagesController < ApplicationController
  def index
  end

  def schedule
  end
end
