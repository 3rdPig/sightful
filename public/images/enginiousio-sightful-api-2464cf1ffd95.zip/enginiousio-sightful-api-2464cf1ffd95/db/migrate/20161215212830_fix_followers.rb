class FixFollowers < ActiveRecord::Migration
  def change
    rename_column :follows , :follower , 'follower_id'
    rename_column :follows , :followee , 'followee_id'
  end
end
