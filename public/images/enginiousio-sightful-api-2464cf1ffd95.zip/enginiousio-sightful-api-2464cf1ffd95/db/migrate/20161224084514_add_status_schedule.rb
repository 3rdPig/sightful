class AddStatusSchedule < ActiveRecord::Migration
  def change
  	add_column :schedules , "status" ,:string
  	add_column :notifications , "to" ,:integer
  	add_column :notifications , "from" ,:integer
  	add_column :notifications , "type" ,:integer
  	add_column :notifications , "body" ,:integer 
  end
end
