class CreateSchedules < ActiveRecord::Migration
  def change
    create_table :schedules do |t|
      t.integer "invitee"
      t.integer "inviter"
      t.datetime "dt"
      t.timestamps null: false
    end
  end
end
