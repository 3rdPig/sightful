class AddHostSchedules < ActiveRecord::Migration
  def change
  	remove_column :users, 'host_id'
  	add_column :schedules , 'host_id' , :integer
  end
end
