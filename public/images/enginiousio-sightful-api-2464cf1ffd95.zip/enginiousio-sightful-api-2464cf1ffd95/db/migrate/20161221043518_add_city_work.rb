class AddCityWork < ActiveRecord::Migration
  def change
  		add_column :works,"city",:string
  end
end
