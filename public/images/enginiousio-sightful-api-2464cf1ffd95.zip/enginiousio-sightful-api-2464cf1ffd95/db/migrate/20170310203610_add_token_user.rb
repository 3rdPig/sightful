class AddTokenUser < ActiveRecord::Migration
  def change
  	add_column :users , 'firtoken' , :string
  end
end
