class RemoveAddressfromAddress < ActiveRecord::Migration
  def change
    remove_column :addresses,:address_id,:integer
    add_column :addresses , :user_id,:integer
  end
end
