class AddDetialsUser < ActiveRecord::Migration
  def change
  	add_column :users , 'zip' , :string
  	add_column :users , 'headline' , :text
  	add_column :users , 'location' , :string
  end
end
