class CreateAddresses < ActiveRecord::Migration
  def change
    create_table :addresses do |t|
      t.integer "zip"
      t.string "city"
      t.string "state"
      t.string "country"
      t.string "line_1"
      t.string "line_2"
      t.timestamps null: false
    end
  end
end
