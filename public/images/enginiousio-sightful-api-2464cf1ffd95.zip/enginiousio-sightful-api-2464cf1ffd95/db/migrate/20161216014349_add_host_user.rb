class AddHostUser < ActiveRecord::Migration
  def change
    remove_column :schedules ,:inviter
    add_column :users ,'host_id',:integer
  end
end
