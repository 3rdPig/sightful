class Readdcolumns < ActiveRecord::Migration
  def change
  	add_column :availabilities ,:from_time , :datetime
    add_column :availabilities , :to_time , :datetime
  end
end