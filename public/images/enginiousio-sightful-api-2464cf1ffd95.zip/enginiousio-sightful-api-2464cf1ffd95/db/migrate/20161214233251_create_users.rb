class CreateUsers < ActiveRecord::Migration
  def change
    create_table :users do |t|
      t.integer "address_id"
      t.string "email"
      t.string "password"
      t.string "auth"
      t.string "phone"
      t.integer "hours"
      t.float "lat"
      t.float "lon"
      t.string "first_name"
      t.string "last_name"
      t.string "dp"
      t.boolean "mentor"
      t.timestamps null: false
    end
  end
end
