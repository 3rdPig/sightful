class AddWorkUser < ActiveRecord::Migration
  def change
  	add_column :users , 'current_company' , :string
  	add_column :users , 'current_title' , :string
  	add_column :users , 'prev_company' , :string
  	add_column :users , 'prev_title' , :string

  	add_column :users , 'grad_school' , :string
  	add_column :users , 'grad_major' , :string
  	add_column :users , 'undergrad_school' , :string
  	add_column :users , 'undergrad_major' , :string
  end
end
