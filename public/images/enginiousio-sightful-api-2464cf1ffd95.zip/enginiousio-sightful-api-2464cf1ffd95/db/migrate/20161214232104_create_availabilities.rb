class CreateAvailabilities < ActiveRecord::Migration
  def change
    create_table :availabilities do |t|
      t.integer "from_day"
      t.integer "to_day"
      t.time "from_time"
      t.time "to_time"
      t.integer "user_id"
      t.timestamps null: false
    end
  end
end