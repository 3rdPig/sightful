class FixSchedule < ActiveRecord::Migration
  def change
  	add_column :schedules , "inviter" ,:integer
  	
  end
end
