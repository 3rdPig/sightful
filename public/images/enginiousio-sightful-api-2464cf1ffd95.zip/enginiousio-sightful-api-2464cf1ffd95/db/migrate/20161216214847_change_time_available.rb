class ChangeTimeAvailable < ActiveRecord::Migration
  def change
    change_column :availabilities ,:from_time ,:string
    change_column :availabilities , :to_time , :string
  end
end
