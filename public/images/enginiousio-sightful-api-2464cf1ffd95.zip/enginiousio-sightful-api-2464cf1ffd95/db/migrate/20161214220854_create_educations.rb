class CreateEducations < ActiveRecord::Migration
  def change
    create_table :educations do |t|
      t.string "degree"
      t.string "unversity"
      t.string "year_completion"
      t.string "degree_type"
      t.string "year_joining"
      t.integer "user_id"
      t.timestamps null: false
    end
  end
end
