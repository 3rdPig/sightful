class CreateWorks < ActiveRecord::Migration
  def change
    create_table :works do |t|
      t.string "company"
      t.string "designation"
      t.string "year_joining"
      t.string "month_joining"
      t.string "year_leaving"
      t.string "month_leaving"
      t.string "country"
      t.integer "user_id"
      t.timestamps null: false
    end
  end
end