class CreateFields < ActiveRecord::Migration
  def change
    create_table :fields do |t|
      t.integer :user_id
      t.string :field
      t.timestamps null: false
    end
  end
end
