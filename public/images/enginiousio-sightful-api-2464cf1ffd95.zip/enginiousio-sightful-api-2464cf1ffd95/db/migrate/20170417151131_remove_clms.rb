class RemoveClms < ActiveRecord::Migration
  def change
  	remove_column :availabilities ,:from_time
    remove_column :availabilities , :to_time
  end
end

